Application screenshots, numbered in the order supplied.
They show the dashboard, database table views, validation messages,
record insertion, and record deletion workflows.
