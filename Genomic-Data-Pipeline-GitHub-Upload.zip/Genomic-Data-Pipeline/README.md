# Genomic Data Pipeline: Sample Management, Gene Sequencing & Mutation Variant Dashboard

## Project Overview
This is a Python-based genomic data management dashboard. It manages sample information, gene records, and mutation variant records using SQLite. On computers with a graphical desktop and Tkinter, it opens a desktop interface. If a graphical interface is unavailable, it can run in console mode.

## Features
- Add genomic sample, gene, and variant records.
- Store organism species, gene symbols, sequence lengths, mutation types, and chromosome positions.
- View a combined Master Genomic Registry.
- View the Samples, Genes, and Variants tables separately.
- Delete a sample, a gene, or an individual variant.
- Use SQLite foreign-key relationships to connect records.
- Initialize the database and insert sample data when the database is empty.
- Use a console menu when a graphical interface is unavailable.

## Technologies
- Python 3
- SQLite (`sqlite3`)
- Tkinter (`tkinter`)

The application uses Python standard-library modules; no third-party Python packages are required.

## Files and Folders
- `genomic_dashboard_final.py` — main application.
- `genomic.db` — SQLite database supplied with sample records.
- `screenshots/` — screenshots of the application and its operations.
- `README.md` — project documentation.
- `.gitignore` — excludes local cache and environment files.

## How to Run

### macOS / Linux
Open Terminal in this project folder and run:

```bash
python3 genomic_dashboard_final.py
```

### Windows
Open Command Prompt or the VS Code terminal in this project folder and run:

```bash
python genomic_dashboard_final.py
```

### Console mode
To explicitly run the text-based interface:

```bash
python3 genomic_dashboard_final.py --console
```

On Windows, use `python` instead of `python3` if that is the command configured on your computer.

## Database Structure
The SQLite database contains three related tables:

1. **samples** — sample name and organism species.
2. **genes** — gene symbol and sequence length, linked to a sample.
3. **variants** — mutation type and chromosome position, linked to a gene.

The application enables SQLite foreign-key enforcement when it opens a database connection.

## Screenshots
See the `screenshots/` folder for examples of the dashboard, table views, adding records, validation messages, and deleting records.

## Academic Project
Developed as an academic project in Data Science and Analytics.
